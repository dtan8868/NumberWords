﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace NumberWords
{
    class Program
    {
        const string FILEPATH = "C:\\NumberWords\\NumberWords.txt";

        enum NUMBER_WORDS
        {
            zero, one, two, three, four, five, six, seven, eight, nine, ten,
            eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, 
            twenty, thirty, forty, fifty, sixty, seventy, eighty, ninety,
            hundred, thousand
        };

        static void Main(string[] args)
        {

            int totalLines = 0;
            int totalWordsInFile = 0;
            int totalSingleWordPerLine = 0;
            int totalMultipleWordsPerLine = 0;
            int totalWordNumbers = 0;

            //Read all lines from the file into a list variable
            var numberFile = File.ReadAllLines(FILEPATH);
            var numberList = new List<string>(numberFile);

            //Get the total number of lines
            totalLines = numberList.Count;

            foreach (string aSingleLine in numberList)
            {
                //Convert the entire line to lower case
                string aLine = aSingleLine.ToLower();

                //For each line, split up the words
                List<string> aWord = aLine.Split(' ').ToList();

                //Increment counter for total words in the file
                totalWordsInFile += aWord.Count;

                //Check if the line has single / multiple words, and increment the counter
                if (aWord.Count == 1)
                    totalSingleWordPerLine++;
                else if (aWord.Count > 1)
                    totalMultipleWordsPerLine++;


                //Keep alpha-numeric characters, strip the rest
                //Example: Convert  "Alpha: Sixty" 
                //          ==>     "Alpha  Sixty"
                //          ==>     "Alpha Sixty"
                Regex rgx = new Regex("[^a-z0-9]");
                aLine = rgx.Replace(aLine, " ");
                aLine = aLine.Replace("  ", " ").TrimEnd();

                //Split up the words
                aWord = aLine.Split(' ').ToList();
                foreach (string aMaybeNumberWord in aWord)
                {
                    //increment counter if the word exists in NUMBER_WORDS
                    totalWordNumbers = Enum.IsDefined(typeof(NUMBER_WORDS), aMaybeNumberWord) ? totalWordNumbers + 1 : totalWordNumbers;
                }

            }


            //Print the Output Summary
            Console.WriteLine("Total lines: " + totalLines.ToString() + "\n");
            Console.WriteLine("Total lines containing one word: " + totalSingleWordPerLine.ToString() + "\n");
            Console.WriteLine("Total lines containing multiple words: " + totalMultipleWordsPerLine.ToString() + "\n");
            Console.WriteLine("Total number of words in file: " + totalWordsInFile.ToString() + "\n");
            Console.WriteLine("Total number words in file: " + totalWordNumbers.ToString() + "\n");

        }
    }
}
